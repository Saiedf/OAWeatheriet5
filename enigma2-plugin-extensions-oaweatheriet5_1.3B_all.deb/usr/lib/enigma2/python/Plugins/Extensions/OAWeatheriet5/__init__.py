# -*- coding: utf-8 -*-

from __future__ import print_function
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
import os


def _get_version():
	try:
		with open(os.path.join(os.path.dirname(__file__), 'version.txt'), 'r') as f:
			return f.read().strip()
	except Exception:
		return "4.1"

__version__ = _get_version()

PluginLanguageDomain = 'OAWeatheriet5'
PluginLanguagePath = 'Extensions/OAWeatheriet5/locale'


isDreambox = False
if os.path.exists("/usr/bin/apt-get"):
	isDreambox = True

isVTi = os.path.exists("/etc/vti-version")
if not isVTi and os.path.exists("/etc/image-version"):
	try:
		with open("/etc/image-version", "r") as f:
			if "vti" in f.read().lower():
				isVTi = True
	except Exception:
		pass


def localeInit():
	if isDreambox:
		lang = language.getLanguage()[:2]
		os.environ["LANGUAGE"] = lang
	gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))


if isDreambox:
	def _(txt):
		return gettext.dgettext(PluginLanguageDomain, txt) if txt else ""
else:
	def _(txt):
		translated = gettext.dgettext(PluginLanguageDomain, txt)
		if translated:
			return translated
		else:
			print(("[%s] fallback to default translation for %s" % (PluginLanguageDomain, txt)))
			return gettext.gettext(txt)

localeInit()
language.addCallback(localeInit)
