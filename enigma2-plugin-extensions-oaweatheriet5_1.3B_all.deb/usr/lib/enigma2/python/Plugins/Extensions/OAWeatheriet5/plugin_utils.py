# -*- coding: utf-8 -*-

from __future__ import print_function

import logging
import re
import sys
from datetime import datetime
from os import listdir
from os.path import exists, isfile, join

# Enigma2 Components
from Components.config import (
	config,
	ConfigElement,
	ConfigSubsection,
	ConfigSelection,
	ConfigText,
	ConfigYesNo
)
from Tools.Directories import SCOPE_CONFIG, SCOPE_PLUGINS, resolveFilename

# Python 2/3 and Image Compatibility
if sys.version_info[0] >= 3:
	from Tools.Directories import SCOPE_SKINS
else:
	from Tools.Directories import SCOPE_SKIN

from . import _, isDreambox, isVTi

MODULE_NAME = "OAWeatheriet5"
PY3 = sys.version_info[0] >= 3

if isDreambox:
	# Hard-coded safety for DreamOS / Gemini to avoid any resolveFilename side-effects
	CACHEFILE = "/etc/enigma2/OAWeatheriet5.dat"
	OAWEATHER_FAV = "/etc/enigma2/oaweatheriet5_fav.json"
else:
	CACHEFILE = resolveFilename(SCOPE_CONFIG, "OAWeatheriet5.dat")
	OAWEATHER_FAV = resolveFilename(SCOPE_CONFIG, "oaweatheriet5_fav.json")

PLUGINPATH = join(resolveFilename(SCOPE_PLUGINS), "Extensions/OAWeatheriet5")
logger = logging.getLogger(MODULE_NAME)
GEODATA = ("Frankfurt am Main, DE", "8.68417,50.11552")

try:
	text_type = unicode
except NameError:
	text_type = str


class OAConfigText(ConfigElement):
	def __init__(self, default="", fixed_size=False, visible_width=False):
		ConfigElement.__init__(self)
		self.value = default

	def handleKey(self, key):
		pass

	def getText(self):
		return str(self.value)

	def getHTML(self, id):
		return ""

	def from_string(self, value):
		self.value = value

	def to_string(self, value):
		return str(value)


def _iter_items_compat(obj):
	if hasattr(obj, "items"):
		try:
			return obj.items()
		except Exception:
			pass
	if hasattr(obj, "iteritems"):
		try:
			return obj.iteritems()
		except Exception:
			pass
	return []


def _to_text_compat(value):
	if value is None:
		return ""
	if PY3:
		return value.decode("utf-8", "ignore") if isinstance(value, bytes) else str(value)
	if isinstance(value, text_type):
		return value
	try:
		return value.decode("utf-8", "ignore")
	except Exception:
		try:
			return text_type(value)
		except Exception:
			return str(value)


def _to_gui_text_compat(value):
	value = _to_text_compat(value)
	if not PY3 and isinstance(value, text_type):
		try:
			return value.encode("utf-8", "ignore")
		except Exception:
			try:
				return str(value)
			except Exception:
				return ""
	return value


def _normalize_iso_datetime(value):
	value = _to_text_compat(value).strip()
	if not value:
		return ""
	value = value.replace("Z", "")
	if "." in value:
		value = value.split(".", 1)[0]
	match = re.search(r"([+-]\d{2}:?\d{2})$", value)
	if match and match.start() > 10:
		value = value[:match.start()]
	return value


def _parse_datetime_compat(value):
	value = _normalize_iso_datetime(value)
	if not value:
		return None
	if PY3 and hasattr(datetime, "fromisoformat"):
		try:
			return datetime.fromisoformat(value)
		except Exception:
			pass
	if not PY3 and isinstance(value, text_type):
		try:
			value = value.encode("ascii", "ignore")
		except Exception:
			pass
	for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
		try:
			return datetime.strptime(value, fmt)
		except Exception:
			continue
	return None


def _isoformat_naive_compat(value):
	dt = value if isinstance(value, datetime) else _parse_datetime_compat(value)
	return dt.isoformat() if dt else ""


def _list_get_compat(values, index, default=None):
	try:
		return values[index]
	except Exception:
		return default


def _first_dict_compat(values, default=None):
	if isinstance(values, dict):
		return values
	if isinstance(values, (list, tuple)) and values and isinstance(values[0], dict):
		return values[0]
	return default if default is not None else {}


def _get_location_name_compat(location):
	if isinstance(location, (list, tuple)) and location:
		return _to_text_compat(location[0])
	return _to_text_compat(location)


def _get_yahoo_code_compat(source_name, code, weather_handler=None):
	if weather_handler is None:
		try:
			from .plugin_weather import weatherhandler as weather_handler
		except Exception:
			weather_handler = None
	if weather_handler is None:
		return "NA"
	try:
		icon_map = weather_handler.WI.convert2icon(source_name, code)
	except Exception:
		icon_map = None
	if not isinstance(icon_map, dict):
		return "NA"
	return icon_map.get("yahooCode", "NA")


def _display_text_compat(value, default=""):
	if value is None:
		value = default
	if isinstance(value, dict):
		for key in ("pvdrCap", "capAbbr", "summary", "description", "text", "value", "name", "title"):
			if key in value:
				text = _display_text_compat(value.get(key), "")
				if text:
					return text
		for _, item in _iter_items_compat(value):
			text = _display_text_compat(item, "")
			if text:
				return text
		return _to_gui_text_compat(default)
	if isinstance(value, (list, tuple)):
		parts = []
		for item in value:
			text = _to_text_compat(_display_text_compat(item, "")).strip()
			if text:
				parts.append(text)
		return _to_gui_text_compat(", ".join(parts) if parts else default)
	text = _to_text_compat(value).strip()
	if not text:
		text = _to_text_compat(default).strip()
	return _to_gui_text_compat(text)


def _build_detail_row(values):
	if not values:
		return []
	row = []
	last_index = len(values) - 1
	for index, value in enumerate(values):
		row.append(value if index == last_index else _display_text_compat(value))
	return row


config.plugins.OAWeatheriet5 = ConfigSubsection()
config.plugins.OAWeatheriet5.enabled = ConfigYesNo(default=False)

ICONSETS = [("", _("Default"))]
if isDreambox:
	ICONSETROOT = "/usr/share/enigma2/WeatherIconSets"
elif sys.version_info[0] >= 3:
	ICONSETROOT = join(resolveFilename(SCOPE_SKINS), "WeatherIconSets")
else:
	ICONSETROOT = join(resolveFilename(SCOPE_SKIN), "WeatherIconSets")

if exists(ICONSETROOT):
	for iconset in listdir(ICONSETROOT):
		if isfile(join(ICONSETROOT, iconset, "0.png")):
			ICONSETS.append((iconset, iconset))

config.plugins.OAWeatheriet5.iconset = ConfigSelection(default="", choices=ICONSETS)
config.plugins.OAWeatheriet5.nighticons = ConfigYesNo(default=True)
config.plugins.OAWeatheriet5.cachedata = ConfigSelection(default="0", choices=[("0", _("Disabled"))] + [("%d" % x, _("%d Minutes") % x) for x in (30, 60, 120)])
config.plugins.OAWeatheriet5.refreshInterval = ConfigSelection(default="120", choices=[("%d" % x, _("%d Minutes") % x) for x in (0, 30, 60, 90, 120, 180, 240, 360, 720, 1440)])
config.plugins.OAWeatheriet5.apikey = ConfigText(default="", visible_width=200, fixed_size=256)
config.plugins.OAWeatheriet5.weathercity = ConfigText(default=GEODATA[0], visible_width=250, fixed_size=False)
config.plugins.OAWeatheriet5.owm_geocode = ConfigText(default=GEODATA[1])
config.plugins.OAWeatheriet5.detailLevel = ConfigSelection(default="default", choices=[("default", _("More Details / Smaller font")), ("reduced", _("Less details / Larger font"))])
config.plugins.OAWeatheriet5.tempUnit = ConfigSelection(default="Celsius", choices=[("Celsius", _("Celsius")), ("Fahrenheit", _("Fahrenheit"))])
config.plugins.OAWeatheriet5.windspeedMetricUnit = ConfigSelection(default="km/h", choices=[("km/h", _("km/h")), ("m/s", _("m/s"))])
config.plugins.OAWeatheriet5.trendarrows = ConfigYesNo(default=True)
config.plugins.OAWeatheriet5.weatherservice = ConfigSelection(default="MSN", choices=[("MSN", _("MSN weather")), ("OpenMeteo", _("Open-Meteo Weather")), ("openweather", _("OpenWeatherMap"))])
config.plugins.OAWeatheriet5.debug = ConfigYesNo(default=False)


def setup_logging():
	log_file = "/tmp/OAWeatheriet5.log"
	log_level = logging.DEBUG if config.plugins.OAWeatheriet5.debug.value else logging.INFO
	formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
	logger.setLevel(log_level)
	logger.propagate = False

	if logger.handlers:
		for existing_handler in list(logger.handlers):
			existing_handler.setLevel(log_level)
			existing_handler.setFormatter(formatter)
		return

	handler = logging.FileHandler(log_file)
	handler.setLevel(log_level)
	handler.setFormatter(formatter)
	logger.addHandler(handler)

	console_handler = logging.StreamHandler()
	console_handler.setLevel(log_level)
	console_handler.setFormatter(formatter)
	logger.addHandler(console_handler)

	logger.info("OAWeatheriet5 logging initialized")


setup_logging()
