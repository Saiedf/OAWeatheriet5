
# -*- coding: utf-8 -*-

from __future__ import print_function

# Copyright (C) 2023 jbleyel, Mr.Servo, Stein17
#
# OAWeatheriet5 is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# dogtag is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with OAWeatheriet5.  If not, see <http://www.gnu.org/licenses/>.

# Some parts are taken from MetrixHD skin and MSNWeather Plugin.
# Updated by lululla 20250629
# - fix Asian language handling and icons 20250706
# - refactor the favorite list
# Updated by lululla 20251209
# - fix error updating config choices: weatherlocation
# - fix error syncing config: weatherlocation

import json
from datetime import datetime, timedelta
from time import time

from os import remove, chmod  # , stat
from os.path import exists, isfile, join

from twisted.internet.reactor import callInThread
from twisted.internet import reactor

from keymapparser import readKeymap

from enigma import eTimer

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import (
	config,
	getConfigListEntry,
	configfile
)

from Plugins.Plugin import PluginDescriptor

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Setup import Setup


from Screens.VirtualKeyBoard import VirtualKeyBoard

# Some images expose only the standard Enigma2 keyboard class.
# Keep the historical name used across this plugin as a safe alias.
CustomVirtualKeyBoard = VirtualKeyBoard



from Tools.LoadPixmap import LoadPixmap

from . import __version__, _, isDreambox
from .plugin_utils import (
	CACHEFILE,
	ICONSETROOT,
	MODULE_NAME,
	OAWEATHER_FAV,
	PLUGINPATH,
	_build_detail_row,
	_first_dict_compat,
	_get_location_name_compat,
	_get_yahoo_code_compat,
	_isoformat_naive_compat,
	_iter_items_compat,
	_list_get_compat,
	_parse_datetime_compat,
	logger,
	text_type,
	isVTi,
	_to_text_compat,
	_to_gui_text_compat
)


from .plugin_weather import WeatherHandler, WeatherHelper, weatherhandler, weatherhelper

def _safestr(val):
	if val is None: return ""
	try: return _to_gui_text_compat(val)
	except: return str(val)



class WeatherSettingsViewNew(Setup):
	setup_title = _("Weather Settings")  # For OpenATV compatibility

	def __init__(self, session):
		self.session = session
		self._closed = False
		self._pending_city_check = None
		self._using_setup_backend = False
		self.onChangedEntry = []
		self.list = []
		self.citylist = []
		self.checkcity = False
		self.closeonsave = False
		self._force_config_types()
		self.skin = weatherhelper.loadSkin("WeatherSettingsViewNew")

		if not self._initNativeSetup(session):
			self["key_green"] = StaticText(_("Save"))
			if isDreambox:
				self["key_blue"] = StaticText(_("Manage Favorites"))
				self["key_yellow"] = StaticText(_("Add City"))
				self["key_red"] = StaticText(_("Select location"))
				self["version"] = StaticText("Ver. " + __version__)
			else:
				self["key_blue"] = StaticText(_("Manage Favorites"))
				self["key_yellow"] = StaticText(_("Defaults"))
				self["key_red"] = StaticText(_("Exit"))
				self["version"] = StaticText("")
			self["help"] = StaticText("")
			self["VKeyIcon"] = Pixmap()

			Screen.__init__(self, session)
			self.setTitle(_('Setup'))
			self.status = ""
			self["status"] = Label()
			self["description"] = Label("")
			self["footnote"] = Label("")
			readKeymap(join(PLUGINPATH, 'keymap.xml'))
			self.old_weatherlocation = config.plugins.OAWeatheriet5.weatherlocation.value
			self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
			ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.changedEntry)

			fallback_actions = {
				"ok": self.keyOK,
				"left": self.keyLeft,
				"right": self.keyRight,
				"cancel": self.safeClose,
				"green": self.keySave,
				"blue": self.manageFavorites
			}
			if isDreambox:
				fallback_actions.update({
					"red": self.keycheckCity,
					"yellow": self.startAddCity
				})
			else:
				fallback_actions.update({
					"red": self.safeClose,
					"yellow": self.defaults
				})

			self["blueActions"] = ActionMap(
				["ColorActions", "OkCancelActions", "OAWeatheriet5Actions"],
				fallback_actions,
				-1
			)
			self.createSetup()
		else:
			self["key_green"] = StaticText(_("Save"))
			self["key_blue"] = StaticText(_("Manage Favorites"))
			self["key_yellow"] = StaticText(_("Defaults"))
			self["key_red"] = StaticText(_("Exit"))
			for widget in ("help", "VKeyIcon", "status", "description", "footnote", "version"):
				if widget not in self:
					self[widget] = StaticText("") if "key" in widget or widget == "version" else Label("")
			self.setTitle(_('Setup'))

			self["blueActions"] = ActionMap(
				["ColorActions", "OkCancelActions", "OAWeatheriet5Actions"],
				{
					"ok": self.keyOK,
					"left": self.keyLeft,
					"right": self.keyRight,
					"cancel": self.safeClose,
					"red": self.safeClose,
					"green": self.keySave,
					"blue": self.manageFavorites,
					"yellow": self.defaults
				},
				-1
			)

		self.old_weatherlocation = config.plugins.OAWeatheriet5.weatherlocation.value
		self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
		if self._applyConfigListLayout not in self.onLayoutFinish:
			self.onLayoutFinish.append(self._applyConfigListLayout)
		logger.info("WeatherSettingsViewNew backend: %s" % ("native Setup" if self._using_setup_backend else "fallback ConfigList"))
		self.onClose.append(self._cleanupOnClose)

	def _initNativeSetup(self, session):
		if isDreambox or isVTi:
			logger.info("DreamOS or VTi detected, forcing fallback ConfigList backend for WeatherSettingsViewNew")
			self._using_setup_backend = False
			return False
		Neue_keymap = join(PLUGINPATH, 'keymap.xml')
		readKeymap(Neue_keymap)
		self._using_setup_backend = True
		self.skinName = ["WeatherSettingsViewNew", "Setup"]
		attempts = (
			((), {"setup": "WeatherSettings", "plugin": "Extensions/OAWeatheriet5"}),
			((), {"setup": "WeatherSettings"}),
			(("WeatherSettings",), {"plugin": "Extensions/OAWeatheriet5"}),
			(("WeatherSettings",), {}),
		)
		last_error = None
		for args, kwargs in attempts:
			try:
				Setup.__init__(self, session, *args, **kwargs)
				return True
			except TypeError as e:
				last_error = e
			except Exception as e:
				last_error = e
				break
		self._using_setup_backend = False
		if last_error is not None:
			logger.warning("Native Setup init failed, using fallback: %s" % _to_text_compat(last_error))
		return False

	def _cancelDelayedCall(self, attr_name):
		delayed = getattr(self, attr_name, None)
		if delayed is None:
			return
		try:
			if delayed.active():
				delayed.cancel()
		except Exception:
			pass
		setattr(self, attr_name, None)

	def _cleanupOnClose(self):
		self._closed = True
		self._cancelDelayedCall("_pending_city_check")

	def safeClose(self):
		self._cleanupOnClose()
		self.close()

	def _force_config_types(self):
		"""Ensure config variables have correct runtime types despite old saved configurations"""
		try:
			val = config.plugins.OAWeatheriet5.refreshInterval.value
			if isinstance(val, text_type):
				config.plugins.OAWeatheriet5.refreshInterval.value = int(val) if val.isdigit() else 120
		except Exception:
			pass
		try:
			val = config.plugins.OAWeatheriet5.cachedata.value
			if isinstance(val, text_type):
				config.plugins.OAWeatheriet5.cachedata.value = int(val) if val.isdigit() else 0
		except Exception:
			pass

	def _getSelectedWeatherLocation(self):
		location = getattr(config.plugins.OAWeatheriet5.weatherlocation, "value", None)
		try:
			for item in getattr(self["config"], "list", []):
				if item and len(item) > 1 and item[1] is config.plugins.OAWeatheriet5.weatherlocation:
					location = item[1].value
					break
		except Exception:
			pass
		return weatherhelper.normalizeLocation(location)

	def _syncSelectedWeatherLocation(self):
		location = self._getSelectedWeatherLocation()
		if not location:
			return None
		return weatherhelper.applyLocationConfig(location)

	def createSetup(self):
		if self._using_setup_backend:
			try:
				Setup.createSetup(self)
				self.list = getattr(self["config"], "list", [])
				if self.list:
					return
			except Exception as e:
				logger.warning("Native Setup.createSetup failed, using fallback: %s" % _to_text_compat(e))
		self._using_setup_backend = False
		self._createFallbackSetup()

	def _createFallbackSetup(self):
		self.editListEntry = None
		self.list = []
		self.list.append(getConfigListEntry(_("Enabled"), config.plugins.OAWeatheriet5.enabled))
		if config.plugins.OAWeatheriet5.enabled.value:
			self.list.append(getConfigListEntry(_("Weather service"), config.plugins.OAWeatheriet5.weatherservice))
			self.list.append(getConfigListEntry(_("Weather city name"), config.plugins.OAWeatheriet5.weatherlocation))
			self.list.append(getConfigListEntry(_("Weather API key"), config.plugins.OAWeatheriet5.apikey))
			self.list.append(getConfigListEntry(_("Detail level in detail view"), config.plugins.OAWeatheriet5.detailLevel))
			self.list.append(getConfigListEntry(_("Temperature unit"), config.plugins.OAWeatheriet5.tempUnit))
			self.list.append(getConfigListEntry(_("Metric unit for wind speed"), config.plugins.OAWeatheriet5.windspeedMetricUnit))
			self.list.append(getConfigListEntry(_("Weather icon set"), config.plugins.OAWeatheriet5.iconset))
			self.list.append(getConfigListEntry(_("Weather icon night switch"), config.plugins.OAWeatheriet5.nighticons))
			self.list.append(getConfigListEntry(_("Show trend arrows for moon data"), config.plugins.OAWeatheriet5.trendarrows))
			self.list.append(getConfigListEntry(_("Refresh interval"), config.plugins.OAWeatheriet5.refreshInterval))
			self.list.append(getConfigListEntry(_("Cache data"), config.plugins.OAWeatheriet5.cachedata))
			self.list.append(getConfigListEntry(_("Enable Debug"), config.plugins.OAWeatheriet5.debug))
		self['config'].list = self.list
		self['config'].l.setList(self.list)
		self._applyConfigListLayout()

	def _getDesktopMetrics(self):
		width = 1280
		height = 720
		try:
			from enigma import getDesktop
			size = getDesktop(0).size()
			width = size.width()
			height = size.height()
		except Exception:
			pass
		return width, height

	def _applyConfigListLayout(self):
		try:
			config_widget = self["config"]
		except Exception:
			return

		width, height = self._getDesktopMetrics()
		is_fhd = width >= 1920 or height >= 1080
		entry_list = getattr(config_widget, "list", None) or getattr(self, "list", [])
		entry_count = max(1, len(entry_list))
		widget_width = 1140
		widget_height = 660 if is_fhd else 550

		try:
			instance = getattr(config_widget, "instance", None)
			if instance is not None:
				size = instance.size()
				widget_width = max(1, size.width())
				widget_height = max(1, size.height())
		except Exception:
			pass

		max_visible_rows = min(entry_count, 14 if is_fhd else 13)
		if max_visible_rows <= 0:
			max_visible_rows = 1
		item_height = int((widget_height - 8) / max_visible_rows)
		if is_fhd:
			item_height = max(34, min(44, item_height))
			font_size = 24 if entry_count <= 10 else 23 if entry_count <= 12 else 22
		else:
			item_height = max(30, min(40, item_height))
			font_size = 23 if entry_count <= 10 else 22 if entry_count <= 12 else 21
		separation = int(widget_width * 0.35)
		separation = max(380, min(widget_width - 120, separation))

		try:
			from enigma import gFont
		except Exception:
			gFont = None

		try:
			if gFont is not None and hasattr(config_widget.l, "setFont"):
				if isDreambox:
					config_widget.l.setFont(gFont("Regular", font_size))
				else:
					config_widget.l.setFont(0, gFont("Regular", font_size))
					try:
						config_widget.l.setFont(1, gFont("Regular", font_size))
					except Exception:
						pass
		except Exception as e:
			logger.warning("Config font layout fallback: %s" % _to_text_compat(e))

		try:
			if hasattr(config_widget.l, "setItemHeight"):
				config_widget.l.setItemHeight(item_height)
			elif getattr(config_widget, "instance", None) is not None and hasattr(config_widget.instance, "setItemHeight"):
				config_widget.instance.setItemHeight(item_height)
		except Exception as e:
			logger.warning("Config itemHeight fallback: %s" % _to_text_compat(e))

		try:
			if hasattr(config_widget.l, "setSeperation"):
				config_widget.l.setSeperation(separation)
		except Exception:
			pass

		try:
			config_widget.l.setList(entry_list)
		except Exception:
			pass

	def keyOK(self):
		current_item = self['config'].getCurrent()
		if current_item:
			if len(current_item) > 1 and current_item[1] == config.plugins.OAWeatheriet5.apikey:
				text = current_item[1].value
				if text == config.plugins.OAWeatheriet5.apikey.value:
					title = _('Please enter a valid API key.')
					self.session.openWithCallback(self.VirtualKeyBoardCallBack, CustomVirtualKeyBoard, title=title, text=text)
	def VirtualKeyBoardCallBack(self, callback):
		try:
			if self._closed:
				return
			if callback:
				current_item = self['config'].getCurrent()
				if current_item and len(current_item) > 1:
					current_item[1].value = callback
					if current_item[1] == config.plugins.OAWeatheriet5.weathercity:
						# Delay 1.0s before opening the ChoiceBox. Enigma2 GUI deadlocks if a modal (ChoiceBox)
						# is opened while the previous modal (VirtualKeyBoard) is still in its fade-out animation.
						from twisted.internet import reactor
						self._cancelDelayedCall("_pending_city_check")
						self._pending_city_check = reactor.callLater(1.0, self.keycheckCity)
		except Exception as e:
			logger.error("VirtualKeyBoardCallBack error: %s" % _to_text_compat(e))

	def AddCityCallBack(self, callback):
		if self._closed:
			return
		if callback:
			config.plugins.OAWeatheriet5.weathercity.value = callback
			from twisted.internet import reactor
			self._cancelDelayedCall("_pending_city_check")
			self._pending_city_check = reactor.callLater(1.0, self.keycheckCity)

	def startAddCity(self):
		title = _('Please enter a valid city name.')
		self.session.openWithCallback(self.AddCityCallBack, CustomVirtualKeyBoard, title=title)

	def keycheckCity(self, closesave=False):
		if self._closed:
			return
		weathercity = config.plugins.OAWeatheriet5.weathercity.value.split(",")[0]
		if len(weathercity) < 3:
			self.showError(_("City name must be at least 3 characters"))
			return

		self.closeonsave = closesave
		weatherhelper.searchLocation(weathercity, self.returnCityChoice, self.session)

	def returnCityChoice(self, selected_location):
		if not selected_location:
			return

		try:
			logger.debug("Init returnCityChoice selected_location= %r" % (selected_location,))

			if isinstance(selected_location, tuple):
				if len(selected_location) == 3:
					city_name, lon, lat = selected_location
				elif len(selected_location) == 2:
					_, coords = selected_location  # discard visual label
					if isinstance(coords, (tuple, list)) and len(coords) == 3:
						city_name, lon, lat = coords
					else:
						raise ValueError("Invalid coordinate format in 2-element tuple")
				else:
					raise ValueError("Unsupported tuple length for location")
			elif isinstance(selected_location, str):
				city_part, coords_part = selected_location.split("[", 1)
				city_name = city_part.strip()
				lon_str, lat_str = coords_part.replace("]", "").split(",")
				lon = float(lon_str.replace("lon=", "").strip())
				lat = float(lat_str.replace("lat=", "").strip())
			else:
				raise ValueError("Unsupported type for location")

			location = (
				weatherhelper.reduceCityname(city_name),
				float(lon),
				float(lat)
			)

			if getattr(self, "addFavorite", False):
				if not self.add2FavList(location):
					self.session.open(
						MessageBox,
						_("Location already in favorites"),
						MessageBox.TYPE_INFO,
						timeout=3
					)
				self.addFavorite = False
			else:
				curr_idx = getattr(self, "currindex", 0)
				if curr_idx < len(getattr(self, "newFavList", [])):
					self.newFavList[curr_idx] = location

			if hasattr(self, "updateFavoriteList"):
				self.updateFavoriteList()

			config.plugins.OAWeatheriet5.weathercity.value = city_name
			config.plugins.OAWeatheriet5.owm_geocode.value = "%s,%s" % (lon, lat)
			config.plugins.OAWeatheriet5.save()

			if getattr(self, "closeonsave", False):
				self.keySave()

		except ValueError as e:
			logger.error("Error parsing city selection: %s" % _to_text_compat(e))
			self.session.open(
				MessageBox,
				_("Invalid location format"),
				MessageBox.TYPE_ERROR,
				timeout=3
			)
		except Exception as e:
			logger.error("Unexpected error: %s" % _to_text_compat(e))
			self.session.open(
				MessageBox,
				_("Error processing location data"),
				MessageBox.TYPE_ERROR,
				timeout=3
			)

	def showError(self, message):
		self.session.open(MessageBox, message, MessageBox.TYPE_WARNING)

	def testScreenOkCallback(self, selected_city_str):
		self.choiceIdxCallback(selected_city_str)

	def choiceIdxCallback(self, selected_city):
		self.selected_city = selected_city

		if len(self.selected_city) >= 4:
			parts = self.selected_city.split(',')
			city = parts[0]
			longitude = ""
			latitude = ""
			for part in parts:
				if 'lon=' in part:
					longitude = part.split('=')[1].strip()
				elif 'lat=' in part:
					latitude = part.split('=')[1].strip((']'))

			if city and longitude and latitude:
				self.saveGeoCode(city, longitude, latitude)
		else:
			logger.info("The selected city does not have enough information.")

	def saveGeoCode(self, city, longitude, latitude):
		config.plugins.OAWeatheriet5.weathercity.value = city
		config.plugins.OAWeatheriet5.owm_geocode.value = "%s,%s" % (longitude, latitude)

		self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
		self.checkcity = False
		if self.closeonsave:
			config.plugins.OAWeatheriet5.owm_geocode.save()
			self.keySave()

	def changedEntry(self):
		for x in self.onChangedEntry:
			x()

	def getCurrentEntry(self):
		try:
			curr = self["config"].getCurrent()
			if curr and len(curr) > 0:
				return _to_gui_text_compat(curr[0])
		except Exception:
			pass
		return ""

	def getCurrentValue(self):
		try:
			curr = self["config"].getCurrent()
			if curr and len(curr) > 1:
				return _to_gui_text_compat(curr[1].getText())
		except Exception:
			pass
		return ""

	def getCurrentDescription(self):
		try:
			curr = self["config"].getCurrent()
			if curr and len(curr) > 2:
				return _to_gui_text_compat(curr[2])
			if curr and len(curr) > 1 and hasattr(curr[1], "description"):
				return _to_gui_text_compat(curr[1].description)
		except Exception:
			pass
		return ""

	def selectionChanged(self):
		try:
			curr = self["config"].getCurrent()
			if self._using_setup_backend:
				if curr is not None:
					Setup.selectionChanged(self)
			else:
				if curr is not None:
					ConfigListScreen.selectionChanged(self)

			for widget_name in ["vkey_icon", "VKeyIcon", "help", "sms", "HelpWindow"]:
				if widget_name in self:
					self[widget_name].hide()
					self[widget_name].show = lambda *a: None
		except Exception as e:
			logger.warning("Selection change safety: %s" % _to_text_compat(e))

	def keyLeft(self):
		if self._using_setup_backend:
			Setup.keyLeft(self)
			self._applyConfigListLayout()
		else:
			ConfigListScreen.keyLeft(self)
			self.createSetup()

	def keyRight(self):
		if self._using_setup_backend:
			Setup.keyRight(self)
			self._applyConfigListLayout()
		else:
			ConfigListScreen.keyRight(self)
			self.createSetup()

	def keySelect(self):
		if self.getCurrentItem() == config.plugins.OAWeatheriet5.weathercity:
			self.checkcity = True
		if self._using_setup_backend:
			Setup.keySelect(self)
		else:
			try:
				Setup.keySelect(self)
			except Exception:
				self.keyOK()

	def keySave(self):
		logger.info("keySave: Starting save process")
		selected_location = self._getSelectedWeatherLocation()

		# Log all config entries with their types before saving
		logger.info("keySave: Saving individual config list entries...")
		for idx, x in enumerate(self["config"].list):
			if len(x) >= 2:
				entry = x[1]
				try:
					val = entry.value
					logger.info("keySave: entry[%d] name=%s type=%s value=%s" % (idx, getattr(entry, '_name', '?'), type(val).__name__, repr(val)))
					entry.save()
				except Exception as e:
					logger.error("keySave: ERROR saving entry[%d]: %s" % (idx, _to_text_compat(e)))

		selected_location = self._syncSelectedWeatherLocation() or selected_location
		if selected_location:
			logger.info("keySave: selected weatherlocation = %r" % (selected_location,))

		weathercity = config.plugins.OAWeatheriet5.weathercity.value.split(",")[0]
		logger.info("keySave: weathercity = '%s' (len=%d)" % (weathercity, len(weathercity)))
		if config.plugins.OAWeatheriet5.enabled.value and len(weathercity) < 3:
			logger.warning("keySave: city name too short, aborting save")
			return

		if not selected_location:
			weatherhelper.syncWithConfig()

		logger.info("keySave: Saving config.plugins.OAWeatheriet5 section...")
		try:
			config.plugins.OAWeatheriet5.save()
			logger.info("keySave: config.plugins.OAWeatheriet5.save() OK")
		except Exception as e:
			logger.error("keySave: config.plugins.OAWeatheriet5.save() FAILED: %s" % _to_text_compat(e))

		# Log all config sections to detect any non-string value
		logger.info("keySave: Scanning all configfile entries for non-string values...")
		try:
			from Components.config import config as _cfg
			def _scan(obj, path=""):
				if hasattr(obj, 'value'):
					v = obj.value
					if not isinstance(v, (text_type, bool, type(None))):
						logger.warning("keySave: NON-STRING entry at '%s': type=%s val=%s" % (path, type(v).__name__, repr(v)))
				for k, sub in _iter_items_compat(obj):
					_scan(sub, path + "." + str(k))
		except Exception as e:
			logger.error("keySave: scan error: %s" % _to_text_compat(e))

		# On Python 2 / DreamOS, configfile.save() requires all values to be strings.
		# Force-convert any numeric config values to string to avoid TypeError.
		logger.info("keySave: Calling configfile.save()...")
		try:
			configfile.save()
			logger.info("keySave: configfile.save() OK")
		except TypeError as e:
			logger.error("keySave: configfile.save() TypeError: %s" % _to_text_compat(e))
			try:
				# Fallback: save only the OAWeatheriet5 config section
				config.plugins.OAWeatheriet5.save()
				logger.info("keySave: fallback save OK")
			except Exception as e2:
				logger.error("keySave: fallback save FAILED: %s" % str(e2))
		except Exception as e:
			logger.error("keySave: configfile.save() unexpected error: %s" % _to_text_compat(e))

		logger.info("keySave: Resetting weather handler...")
		try:
			weatherhandler.reset()
			self.old_weatherlocation = config.plugins.OAWeatheriet5.weatherlocation.value
			self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
			logger.info("keySave: weatherhandler.reset() OK")
		except Exception as e:
			logger.error("keySave: weatherhandler.reset() FAILED: %s" % _to_text_compat(e))
		logger.info("keySave: Calling super().keySave()...")
		if self._using_setup_backend:
			Setup.keySave(self)
		else:
			try:
				ConfigListScreen.keySave(self)
			except Exception:
				self.safeClose()
		logger.info("keySave: Done.")

	def defaults(self, SAVE=False):
		for x in self["config"].list:
			if len(x) > 1:
				self.setInputToDefault(x[1], SAVE)
		self.setInputToDefault(config.plugins.OAWeatheriet5.owm_geocode, SAVE)
		if self.session:
			self.createSetup()
			if not self._using_setup_backend:
				self['config'].setList(self.list)
			self['status'].setText(_("Standard finished"))

	def setInputToDefault(self, configItem, SAVE):
		configItem.setValue(configItem.default)
		if SAVE:
			configItem.save()

	def manageFavorites(self):
		self.session.openWithCallback(
			self.favoriteManagementClosed,
			OAWeatheriet5Favorites
		)

	def favoriteManagementClosed(self, result=None):
		weatherhelper.readFavoriteList()
		self.createSetup()


def main(session, **kwargs):
	session.open(OAWeatheriet5Plugin)


def setup(session, **kwargs):
	session.open(WeatherSettingsViewNew)


def sessionstart(session, **kwargs):
	from Components.Sources.OAWeatheriet5 import OAWeatheriet5
	session.screen["OAWeatheriet5"] = OAWeatheriet5()
	session.screen["OAWeatheriet5"].precipitationtext = _("Precipitation")
	session.screen["OAWeatheriet5"].humiditytext = _("Humidity")
	session.screen["OAWeatheriet5"].feelsliketext = _("Feels like")
	session.screen["OAWeatheriet5"].pluginpath = PLUGINPATH
	iconpath = config.plugins.OAWeatheriet5.iconset.value
	if iconpath:
		iconpath = join(ICONSETROOT, iconpath)
	else:
		iconpath = join(PLUGINPATH, "Icons")
	session.screen["OAWeatheriet5"].iconpath = iconpath
	weatherhandler.sessionStart(session)


def Plugins(**kwargs):
	pluginList = []
	pluginList.append(PluginDescriptor(name="OAWeatheriet5", where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart, needsRestart=False))
	pluginList.append(PluginDescriptor(name="OAWeather by iet5", description="Show Weather Cast Moded by iet5", icon="plugin.png", where=[PluginDescriptor.WHERE_PLUGINMENU], fnc=main))
	pluginList.append(PluginDescriptor(name="OAWeather by iet5", description="Show Weather Cast Moded by iet5", icon="plugin.png", where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main))
	return pluginList


class OAWeatheriet5Plugin(Screen):

	def __init__(self, session):
		logger.info("OAWeatheriet5Plugin initialized")
		self._closing = False
		self._pending_reset_call = None
		self._lastFavoriteSwitchAt = 0
		self.skin = weatherhelper.loadSkin("OAWeatheriet5Plugin")
		Screen.__init__(self, session)
		self.onClose.append(self._cleanupOnClose)

		try:
			weatherLocation = weatherhelper.resolveConfiguredLocation(require_favorite=False)
			matched_location = weatherhelper.getFavoriteLocation(weatherLocation)
			if matched_location and matched_location in weatherhelper.favoriteList:
				self.currFavIdx = weatherhelper.favoriteList.index(matched_location)
				weatherhelper.applyLocationConfig(matched_location, save=True)
			elif weatherLocation:
				self.currFavIdx = 0
				weatherhelper.applyLocationConfig(weatherLocation, save=True)
			else:
				self.currFavIdx = 0
				fallback_location = weatherhelper.favoriteList[self.currFavIdx] if weatherhelper.favoriteList else weatherhelper.locationDefault
				weatherhelper.applyLocationConfig(fallback_location, save=True)
				weatherLocation = fallback_location
		except Exception:
			weatherLocation = weatherhelper.locationDefault
			self.currFavIdx = 0

		Neue_keymap = join(PLUGINPATH, 'keymap.xml')
		readKeymap(Neue_keymap)
		self.data = {}
		self.na = _("n/a")
		self.title = "OAWeather by iet5"
		self["version"] = StaticText("OA-Weather " + str(weatherhelper.version))
		self["statustext"] = StaticText()
		self["description"] = Label(_('GREEN: MANAGEMENT FAVORITES | MENU: SETUP | INFO: DETAILS | HOME'))
		self["update"] = Label(_("Update"))
		self["current"] = Label(_("Current Weather"))
		self["today"] = StaticText(_("Today"))
		self["key_red"] = StaticText(_("Exit"))
		self["key_green"] = StaticText(_("Chose favorite"))
		self["key_yellow"] = StaticText(_("Previous favorite"))
		self["key_blue"] = StaticText(_("Next favorite"))
		self["key_ok"] = StaticText(_("View details"))
		self["key_menu"] = StaticText(_("Settings"))
		self["actions"] = ActionMap(
			["OAWeatheriet5Actions", "ColorActions", "InfoActions"],
			{
				"ok": self.keyOk,
				"cancel": self.safeClose,
				"red": self.safeClose,
				"yellow": self.favoriteUp,
				"blue": self.favoriteDown,
				"left": self.favoriteUp,
				"right": self.favoriteDown,
				"green": self.favoriteChoice,
				"menu": self.config,
				"info": self.keyOk
			},
			-1
		)
		for i in range(1, 6):
			self["weekday%s_temp" % i] = StaticText()

		self.onLayoutFinish.append(self.startRun)

	def _cancelDelayedCall(self, attr_name):
		delayed = getattr(self, attr_name, None)
		if delayed is None:
			return
		try:
			if hasattr(delayed, "active") and delayed.active():
				delayed.cancel()
		except Exception:
			pass
		setattr(self, attr_name, None)

	def _stopCheckTimer(self):
		timer = getattr(self, "checkDataTimer", None)
		if timer is None:
			return
		try:
			timer.stop()
		except Exception:
			pass
		self.checkDataTimer = None

	def _cleanupOnClose(self):
		self._closing = True
		self._cancelDelayedCall("_pending_reset_call")
		self._stopCheckTimer()

	def safeClose(self):
		self._cleanupOnClose()
		# Save config one last time on orderly close to ensure all navigation is persisted
		try:
			self.saveConfig()
		except Exception:
			pass
		self.close()

	def startRun(self):
		if self._closing:
			return
		if getattr(self, "checkDataTimer", None) is not None:
			try:
				self.checkDataTimer.stop()
			except:
				pass

		if not weatherhandler.getData() or weatherhandler.getValid() != 0:
			self["statustext"].text = _("Loading weather data...")
			try:
				location_data = config.plugins.OAWeatheriet5.weatherlocation.value
				callInThread(weatherhandler.reset, location_data)
			except:
				callInThread(weatherhandler.reset)
		else:
			self.data = weatherhandler.getData() or {}
			self.getWeatherDataCallback()

		self.checkDataTimer = eTimer()
		try:
			# OpenATV / OpenSource images
			self.checkDataTimer.callback.append(self.checkDataUpdate)
		except AttributeError:
			try:
				# DreamOS older API
				self.checkDataTimer.timeout.get().append(self.checkDataUpdate)
			except AttributeError:
				# DreamOS newer API
				self.checkDataTimer.timeout.connect(self.checkDataUpdate)
		self.checkDataTimer.start(1000)

	def checkDataUpdate(self):
		if self._closing:
			self._stopCheckTimer()
			return
		if weatherhandler.getValid() == 0:
			self.data = weatherhandler.getData()
			self.getWeatherDataCallback()
			self.checkDataTimer.stop()
		elif weatherhandler.getValid() == 2:
			self.error(_("Weather data unavailable"))
			self.checkDataTimer.stop()

	def clearFields(self):
		for idx in range(1, 6):
			self["weekday%s_temp" % idx].text = ""

	def getVal(self, key):
		return self.data.get(key, self.na) if self.data else self.na

	def getCurrentVal(self, key, default=None):
		if default is None:
			default = _("n/a")
		value = default
		if self.data and "current" in self.data:
			current = self.data.get("current", {})
			if key in current:
				value = current.get(key, default)
		return value

	def getWeatherDataCallback(self):
		if self._closing:
			return
		self["statustext"].text = ""
		forecast = self.data.get("forecast", {})
		tempunit = self.data.get("tempunit", self.na)
		for day in range(1, 6):
			item = forecast.get(day, {})
			lowTemp = item.get("minTemp", "")
			highTemp = item.get("maxTemp", "")
			text = item.get("text", "")
			self["weekday%d_temp" % day].text = _to_gui_text_compat(u"%s %s|%s %s\n%s" % (highTemp, tempunit, lowTemp, tempunit, text))

	def _getDetailLocation(self):
		try:
			location = config.plugins.OAWeatheriet5.weatherlocation.value
			if isinstance(location, (list, tuple)) and len(location) >= 3:
				return location
		except Exception:
			pass
		if weatherhelper.favoriteList:
			try:
				return weatherhelper.favoriteList[self.currFavIdx]
			except Exception:
				return weatherhelper.favoriteList[0]
		return None

	def keyOk(self):
		location = self._getDetailLocation()
		if not location:
			self["statustext"].text = _("No location available")
			return
		try:
			self["statustext"].text = ""
			self.session.open(OAWeatheriet5Detailview, location)
		except Exception as e:
			logger.error("Error opening detail view: %s" % _to_text_compat(e))
			self["statustext"].text = _("Unable to open detail view")

	def _favoriteChanged(self, result=None):
		if self._closing:
			return
		logger.info("favorite navigation callback completed")
		self._cancelDelayedCall("_pending_reset_call")
		self["statustext"].text = ""
		self.startRun()

	def _applyFavoriteLocation(self, location):
		now = time()
		if now - self._lastFavoriteSwitchAt < 0.5:
			logger.info("Ignoring repeated favorite navigation event")
			return
		self._lastFavoriteSwitchAt = now
		self._cancelDelayedCall("_pending_reset_call")
		location = weatherhelper.applyLocationConfig(location, save=True, persist=True)
		if not location:
			return
		matched_location = weatherhelper.getFavoriteLocation(location) or location
		if matched_location in weatherhelper.favoriteList:
			self.currFavIdx = weatherhelper.favoriteList.index(matched_location)
		logger.info("favorite navigation switching to %s" % repr(matched_location))
		self.clearFields()
		self["statustext"].text = _("Loading weather data...")
		callInThread(weatherhandler.reset, matched_location, self._favoriteChanged)

	def favoriteUp(self):
		if weatherhelper.favoriteList:
			current_location = weatherhelper.getFavoriteLocation(config.plugins.OAWeatheriet5.weatherlocation.value)
			if current_location and current_location in weatherhelper.favoriteList:
				self.currFavIdx = weatherhelper.favoriteList.index(current_location)
			self.currFavIdx = (self.currFavIdx - 1) % len(weatherhelper.favoriteList)
			self._applyFavoriteLocation(weatherhelper.favoriteList[self.currFavIdx])

	def favoriteDown(self):
		if weatherhelper.favoriteList:
			current_location = weatherhelper.getFavoriteLocation(config.plugins.OAWeatheriet5.weatherlocation.value)
			if current_location and current_location in weatherhelper.favoriteList:
				self.currFavIdx = weatherhelper.favoriteList.index(current_location)
			self.currFavIdx = (self.currFavIdx + 1) % len(weatherhelper.favoriteList)
			self._applyFavoriteLocation(weatherhelper.favoriteList[self.currFavIdx])

	def favoriteChoice(self):
		"""Opens the complete favorite management screen"""
		self.session.openWithCallback(
			self.favoriteManagementClosed,
			OAWeatheriet5Favorites
		)

	def favoriteManagementClosed(self, result=None):
		"""Callback when the favorite management screen is closed"""
		if result:
			self._applyFavoriteLocation(result)

	def returnFavoriteChoice(self, favorite):
		weatherhelper.handleFavoriteSelection(favorite, self._favoriteChanged)

	def saveConfig(self):
		config.plugins.OAWeatheriet5.save()
		config.save()

	def config(self):
		self.session.openWithCallback(self.configFinished, WeatherSettingsViewNew)

	def configFinished(self, result=None):
		if self._closing:
			return
		self.clearFields()
		# Execute reset safely on the main thread after a short delay
		from twisted.internet import reactor
		self._cancelDelayedCall("_pending_reset_call")
		self._pending_reset_call = reactor.callLater(0.2, self._delayedReset)

	def _delayedReset(self):
		self._pending_reset_call = None
		if self._closing:
			return
		weatherhandler.reset()
		self.startRun()

	def error(self, errortext):
		self.clearFields()
		self["statustext"].text = errortext


class OAWeatheriet5DetailFrame(Screen):
	def __init__(self, session):
		self.skin = weatherhelper.loadSkin("OAWeatheriet5DetailFrame")
		Screen.__init__(self, session)
		self.widgets = (
			"time", "pressure", "temp", "feels", "humid", "precip", "windspeed",
			"winddir", "windgusts", "uvindex", "visibility", "shortdesc", "longdesc"
		)
		for widget in self.widgets:
			self[widget] = StaticText()
		self["icon"] = Pixmap()

	def showFrame(self):
		self.show()

	def updateFrame(self, dataList):
		try:
			widgets = (
				"time", "pressure", "temp", "feels", "humid", "precip", "windspeed",
				"winddir", "windgusts", "uvindex", "visibility", "shortdesc", "longdesc"
			)

			# Ensure we have at least 14 elements
			if not dataList or len(dataList) < 14:
				dataList = [_("N/A")] * 14

			for index, widget in enumerate(widgets):
				value = dataList[index] if index < len(dataList) else _("n/a")
				self[widget].setText(str(value))

			icon = dataList[13] if len(dataList) > 13 else None
			self["icon"].instance.setPixmap(icon)
			self.showFrame()
		except Exception as e:
			logger.error("Error updating detail frame: %s" % _to_text_compat(e))

	def hideFrame(self):
		self.hide()


class OAWeatheriet5Detailview(Screen):
	YAHOOnightswitch = {
		"3": "47", "4": "47", "11": "45", "12": "45", "13": "46", "14": "46", "15": "46", "16": "46", "28": "27",
		"30": "29", "32": "31", "34": "33", "37": "47", "38": "47", "40": "45", "41": "46", "42": "46", "43": "46"
	}
	YAHOOdayswitch = {"27": "28", "29": "30", "31": "32", "33": "34", "45": "39", "46": "16", "47": "4"}

	def __init__(self, session, currlocation):
		self.skin = weatherhelper.loadSkin("OAWeatheriet5Detailview")
		self._closing = False
		self._pending_reset_call = None
		Screen.__init__(self, session)
		self.detailFrame = self.session.instantiateDialog(OAWeatheriet5DetailFrame)
		self.detailFrameActive = False
		self.currFavIdx = weatherhelper.favoriteList.index(currlocation) if currlocation in weatherhelper.favoriteList else 0
		self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value

		self.detailLevels = config.plugins.OAWeatheriet5.detailLevel.choices
		self.detailLevelIdx = config.plugins.OAWeatheriet5.detailLevel.choices.index(
			config.plugins.OAWeatheriet5.detailLevel.value
		)

		self.currdatehour = datetime.today().replace(minute=0, second=0, microsecond=0)
		self.currdaydelta = 0
		self.skinList = []
		self.dayList = [[]]
		self.sunList = []
		self.moonList = []
		self.na = _("n/a")

		self.currdaydelta = 0
		self.currdatehour = datetime.today().replace(
			minute=0, second=0, microsecond=0
		)
		self.title = _("Weather Plugin Detailview")
		self.detailPageSize = 8
		self["version"] = StaticText("OA-Weather " + str(weatherhelper.version))
		self["detailList"] = List()
		self["update"] = Label(_("Update"))
		self["currdatetime"] = Label(self.currdatehour.strftime("%a %d %b"))
		self["cityarea"] = Label(_to_gui_text_compat(_get_location_name_compat(currlocation)))
		self["sunrise"] = StaticText(self.na)
		self["sunset"] = StaticText(self.na)
		self["moonrise"] = StaticText("")
		self["moonset"] = StaticText("")
		self["moonrisepix"] = Pixmap()
		self["moonsetpix"] = Pixmap()
		self["key_red"] = StaticText(_("Exit"))
		self["key_green"] = StaticText(_("Chose favorite"))
		self["key_yellow"] = StaticText(_("Previous favorite"))
		self["key_blue"] = StaticText(_("Next favorite"))
		self["key_channel"] = StaticText(_("Day +/-"))
		self["key_info"] = StaticText(_("Details +/-"))
		self["key_ok"] = StaticText(_("Glass"))
		self["actions"] = ActionMap(
			["OAWeatheriet5Actions", "ColorActions", "InfoActions"],
			{
				"ok": self.toggleDetailframe,
				"cancel": self.exit,
				"up": self.prevEntry,
				"down": self.nextEntry,
				"right": self.pageDown,
				"left": self.pageUp,
				"red": self.exit,
				"yellow": self.favoriteUp,
				"blue": self.favoriteDown,
				"green": self.favoriteChoice,
				"channeldown": self.prevDay,
				"channelup": self.nextDay,
				"info": self.toggleDetailLevel,
				"menu": self.config
			},
			-1
		)
		self["statustext"] = StaticText()
		self.pressPix = self.getPixmap("barometer.png")
		self.tempPix = self.getPixmap("temp.png")
		self.feelPix = self.getPixmap("feels.png")
		self.humidPix = self.getPixmap("hygrometer.png")
		self.precipPix = self.getPixmap("umbrella.png")
		self.WindSpdPpix = self.getPixmap("wind.png")
		self.WindDirPix = self.getPixmap("compass.png")
		self.WindGustPix = self.getPixmap("windgust.png")
		self.uvIndexPix = self.getPixmap("uv_index.png")
		self.visiblePix = self.getPixmap("binoculars.png")
		self.onLayoutFinish.append(self.firstRun)
		self.onClose.append(self._cleanupOnClose)
	def exit(self):
		self._cleanupOnClose()
		# Save config on exit to persist favorite changes from Detailview
		try:
			config.plugins.OAWeatheriet5.save()
			config.save()
		except Exception:
			pass
		self.close()

	def _cancelDelayedCall(self, attr_name):
		delayed = getattr(self, attr_name, None)
		if delayed is None:
			return
		try:
			if hasattr(delayed, "active") and delayed.active():
				delayed.cancel()
		except Exception:
			pass
		setattr(self, attr_name, None)

	def _cleanupOnClose(self):
		self._closing = True
		self._cancelDelayedCall("_pending_reset_call")
		try:
			if getattr(self, "detailFrame", None) is not None:
				try:
					if hasattr(self.detailFrame, "hideFrame"):
						self.detailFrame.hideFrame()
					else:
						self.detailFrame.hide()
				except Exception:
					pass
				try:
					self.session.deleteDialog(self.detailFrame)
				except Exception:
					pass
				self.detailFrame = None
		except Exception:
			pass
		self.detailFrameActive = False

	def firstRun(self):
		if self._closing:
			return
		moonrisepix = join(PLUGINPATH, "Images/moonrise.png")
		moonsetpix = join(PLUGINPATH, "Images/moonset.png")

		if exists(moonrisepix):
			self["moonrisepix"].instance.setPixmapFromFile(moonrisepix)
		else:
			self["moonrisepix"].hide()

		if exists(moonsetpix):
			self["moonsetpix"].instance.setPixmapFromFile(moonsetpix)
		else:
			self["moonsetpix"].hide()

		self["detailList"].style = self.detailLevels[self.detailLevelIdx]
		self.updateDisplay()
		self.startRun()

	def startRun(self):
		if self._closing:
			return
		if weatherhandler.getValid() == 0:
			self._doParseData()
		else:
			callInThread(self.parseData)

	def updateSkinList(self):
		try:
			weekday = _('Today') if self.currdatehour.weekday() == datetime.today().weekday() else self.currdatehour.strftime("%a")
			self["currdatetime"].setText(weekday + " " + self.currdatehour.strftime("%d %b"))

			iconpix = [
				self.pressPix, self.tempPix, self.feelPix,
				self.humidPix, self.precipPix, self.WindSpdPpix,
				self.WindDirPix, self.WindGustPix,
				self.uvIndexPix,
				self.visiblePix
			]

			skinList = []
			if self.dayList and self.currdaydelta < len(self.dayList):
				hourData = self.dayList[self.currdaydelta]
				for hour in hourData:
					skinList.append(tuple(hour + iconpix))

			if not skinList:
				# Create default "No data" entry
				no_data = [
					_("No data"), "--", "--", "--", "--", "--",
					"--", "--", "--", "--", "--",
					_("Weather data unavailable"),
					_("Try refreshing or check settings"),
					self.pressPix
				]
				skinList = [tuple(no_data + iconpix)]

			self["detailList"].setList(skinList)
			self.skinList = skinList
			self.updateDetailFrame()
		except Exception as e:
			logger.error("Error updating skin list: %s" % _to_text_compat(e))

	def _getDetailListCount(self):
		return len(self.skinList) if self.skinList else 0

	def _getDetailListIndex(self):
		try:
			return self["detailList"].getIndex()
		except Exception:
			return 0

	def _setDetailListIndex(self, index):
		count = self._getDetailListCount()
		if count <= 0:
			self.updateDetailFrame()
			return
		self["detailList"].setIndex(index % count)
		self.updateDetailFrame()

	def updateDetailFrame(self):
		if self._closing or getattr(self, "detailFrame", None) is None:
			return
		if self.detailFrameActive:
			current = self["detailList"].getCurrent()
			if current is not None:
				# Extract only the data fields (first 14 elements)
				data_fields = list(current)[:14]
				self.detailFrame.updateFrame(data_fields)
			else:
				self.detailFrame.updateFrame(None)

	def toggleDetailframe(self):
		try:
			if self.detailFrameActive:
				self.detailFrame.hideFrame()
			else:
				self.detailFrame.showFrame()  # Show the frame
			self.detailFrameActive = not self.detailFrameActive
			self.updateDetailFrame()
		except Exception as e:
			logger.error("Error toggling detail frame: %s" % _to_text_compat(e))
			self.detailFrameActive = False

	def toggleDetailLevel(self):
		currIndex = self._getDetailListIndex()
		self.detailLevelIdx ^= 1
		self["detailList"].style = self.detailLevels[self.detailLevelIdx]
		self["detailList"].setList(self.skinList)
		if self._getDetailListCount() > 0:
			self["detailList"].setIndex(currIndex % self._getDetailListCount())
		self.updateDetailFrame()

	def updateMoonData(self):
		if self._closing:
			return
		if self.moonList and self.currdaydelta < len(self.moonList):
			moonrise = _parse_datetime_compat(self.moonList[self.currdaydelta][0])
			moonset = _parse_datetime_compat(self.moonList[self.currdaydelta][1])
			self["moonrise"].setText(moonrise.strftime("%H:%M") if moonrise else "")
			self["moonset"].setText(moonset.strftime("%H:%M") if moonset else "")
			self["moonrisepix"].show()
			self["moonsetpix"].show()
		else:
			self["moonrise"].setText("")
			self["moonset"].setText("")
			self["moonrisepix"].hide()
			self["moonsetpix"].hide()
		if self.sunList and self.currdaydelta < len(self.sunList):
			sunrise = _parse_datetime_compat(self.sunList[self.currdaydelta][0])
			sunset = _parse_datetime_compat(self.sunList[self.currdaydelta][1])
			self["sunrise"].setText(sunrise.strftime("%H:%M") if sunrise else "")
			self["sunset"].setText(sunset.strftime("%H:%M") if sunset else "")
		else:
			self["sunrise"].setText("")
			self["sunset"].setText("")

	def getPixmap(self, filename):
		iconfile = join(PLUGINPATH, "Images/" + filename)
		return LoadPixmap(cached=True, path=iconfile) if exists(iconfile) else LoadPixmap(cached=True, path=join(PLUGINPATH, "Images/update.png"))

	def _updateLocationLabel(self, location=None):
		if location is None and weatherhelper.favoriteList:
			location = weatherhelper.favoriteList[self.currFavIdx]
		try:
			self["cityarea"].setText(_get_location_name_compat(location))
		except Exception:
			pass

	def parseData(self, *args, **kwargs):
		if self._closing:
			return
		from twisted.internet import reactor
		try:
			# If we are already on main thread (unlikely when called from handler, 
			# but possible if called manually), just run it.
			if reactor.getThreadPool()._workerCount == 0: # This is a bit hacky but safer:
				self._doParseData(*args, **kwargs)
			else:
				reactor.callFromThread(self._doParseData, *args, **kwargs)
		except Exception:
			reactor.callFromThread(self._doParseData, *args, **kwargs)

	def _doParseData(self, *args, **kwargs):
		if self._closing:
			return
		try:
			weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
			if weatherservice in ["MSN", "OpenMeteo", "openweather"]:
				parser = {
					"MSN": self.msnparser,
					"OpenMeteo": self.omwparser,
					"openweather": self.owmparser
				}
				parser[weatherservice]()
			else:
				logger.warning("Unsupported service: " + str(weatherservice))
				self.dayList = []

			# Initialize dayList if empty
			if not hasattr(self, "dayList") or not self.dayList:
				self.dayList = [[]]  # List with one empty day

		except Exception as e:
			logger.error("Data parsing error: %s" % _to_text_compat(e))
			self.dayList = [[]]
		finally:
			self.updateDisplay()


	def msnparser(self):
		iconpath = config.plugins.OAWeatheriet5.iconset.value
		iconpath = join(ICONSETROOT, iconpath) if iconpath else join(PLUGINPATH, "Icons")
		dayList = []
		responses = weatherhandler.getFulldata().get("responses")
		if responses:  # collect latest available data
			weather = responses[0].get("weather", [{}])[0]
			current = weather.get("current", {})
			nowcasting = weather.get("nowcasting", {})
			today = weather.get("forecast", {}).get("days", [{}])[0]
			almanac = today.get("almanac", {})
			sunrisestr = _isoformat_naive_compat(almanac.get("sunrise", ""))
			sunsetstr = _isoformat_naive_compat(almanac.get("sunset", ""))
			created = current.get("created")
			currtime = _parse_datetime_compat(created)
			timestr = currtime.strftime("%H:%M h") if currtime else ""
			tempunit = "°C" if config.plugins.OAWeatheriet5.tempUnit.value == "Celsius" else "°F"
			press = str(round(current.get('baro', 0))) + " mbar"
			temp = str(round(current.get('temp', 0))) + " " + tempunit
			feels = str(round(current.get('feels', 0))) + " " + tempunit
			humid = str(round(current.get('rh', 0))) + " %"
			hourly = today["hourly"]
			precip = str(round(hourly[0]['precip'])) + " %" if len(hourly) else self.na  # workaround: use value from next hour if available
			windSpd = str(round(current.get('windSpd', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
			windDir = _(weatherhandler.WI.directionsign(round(current.get('windDir', 0))))
			windGusts = str(round(current.get('windGust', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
			uvIndex = str(round(current.get('uv', 0)))
			visibility = str(round(current.get('vis', 0))) + " km"
			shortDesc = current.get("pvdrCap", "")
			longDesc = nowcasting.get("summary", "")
			yahoocode = _get_yahoo_code_compat("MSN", current.get("symbol", ""))
			yahoocode = self.nightSwitch(yahoocode, self.getIsNight(currtime, sunrisestr, sunsetstr))
			iconfile = join(iconpath, yahoocode + ".png")
			iconpix_load = LoadPixmap(cached=True, path=iconfile) if iconfile and exists(iconfile) else self.pressPix
			hourData = []
			raw_data = [timestr, press, temp, feels, humid, precip, windSpd, windDir, windGusts, uvIndex, visibility, shortDesc, longDesc, iconpix_load]
			hourData.append([_safestr(x) for x in raw_data[:-1]] + [raw_data[-1]])
			days = weather["forecast"]["days"]
			if days:
				self.sunList = []
				self.moonList = []
				for index, day in enumerate(days):  # collect data on future hours of current day
					if index:
						hourData = []
					almanac = day.get("almanac", {})
					sunrisestr = almanac.get("sunrise", "")
					sunrisestr = _isoformat_naive_compat(sunrisestr)
					sunsetstr = almanac.get("sunset", "")
					sunsetstr = _isoformat_naive_compat(sunsetstr)
					moonrisestr = almanac.get("moonrise", "")
					moonrisestr = _isoformat_naive_compat(moonrisestr)
					moonsetstr = almanac.get("moonset", "")
					moonsetstr = _isoformat_naive_compat(moonsetstr)
					for hour in day.get("hourly", []):
						valid = hour.get("valid")
						currtime = _parse_datetime_compat(valid)
						timestr = currtime.strftime("%H:%M h") if currtime else ""
						press = str(round(hour.get('baro', 0))) + " mbar"
						tempunit = "°C" if config.plugins.OAWeatheriet5.tempUnit.value == "Celsius" else "°F"
						temp = str(round(hour.get('temp', 0))) + " " + tempunit
						feels = str(round(hour.get('feels', 0))) + " " + tempunit
						humid = str(round(hour.get('rh', 0))) + " %"
						precip = str(round(hour.get('precip', 0))) + " %"
						windSpd = str(round(hour.get('windSpd', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
						windDir = _(weatherhandler.WI.directionsign(round(hour.get('windDir', 0))))
						windGusts = str(round(hour.get('windGust', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
						uvIndex = str(round(hour.get('uv', 0)))
						visibility = str(round(hour.get('vis', 0))) + " km"
						shortDesc = hour.get("pvdrCap", "")  # e.g. 'cloudy'
						longDesc = hour.get("summary", "")  # e.g. "The sky becomes cloudy."
						yahoocode = _get_yahoo_code_compat("MSN", hour.get("symbol", ""))  # e.g. 'n4000' -> {'yahooCode': '26', 'meteoCode': 'Y'}
						yahoocode = self.nightSwitch(yahoocode, self.getIsNight(currtime, sunrisestr, sunsetstr))
						iconfile = join(iconpath, yahoocode + ".png")
						iconpix_load = LoadPixmap(cached=True, path=iconfile) if iconfile and exists(iconfile) else self.pressPix
						raw_data = [timestr, press, temp, feels, humid, precip, windSpd, windDir, windGusts, uvIndex, visibility, shortDesc, longDesc, iconpix_load]
						hourData.append([_safestr(x) for x in raw_data[:-1]] + [raw_data[-1]])
					dayList.append(hourData)
					self.sunList.append((sunrisestr, sunsetstr))
					self.moonList.append((moonrisestr, moonsetstr))
		self.dayList = dayList

	def omwparser(self):
		iconpath = config.plugins.OAWeatheriet5.iconset.value
		iconpath = join(ICONSETROOT, iconpath) if iconpath else join(PLUGINPATH, "Icons")
		fulldata = weatherhandler.getFulldata()
		if fulldata:
			daily = fulldata.get("daily", {})
			sunriseList = daily.get("sunrise", [])
			sunsetList = daily.get("sunset", [])
			self.sunList = []
			for index, sunrisestr in enumerate(sunriseList):
				sunsetstr = sunsetList[index] if index < len(sunsetList) else ""
				self.sunList.append((sunrisestr if sunrisestr else self.na, sunsetstr if sunsetstr else self.na))
			self.moonList = []  # OMW does not support moonrise / moonset at all
			hourly = fulldata.get("hourly", {})
			dayList = []
			if hourly:
				timeList = hourly.get("time", [])
				pressList = hourly.get("pressure_msl", [])
				tempList = hourly.get("temperature_2m", [])
				feelsList = hourly.get("apparent_temperature", [])
				humidList = hourly.get("relativehumidity_2m", [])
				precipList = hourly.get("precipitation_probability", [])
				wSpeedList = hourly.get("windspeed_10m", [])
				wGustList = hourly.get("wind_gusts_10m", [])
				wDirList = hourly.get("winddirection_10m", [])
				uvList = hourly.get("uv_index", [])
				visList = hourly.get("visibility", [])
				wCodeList = hourly.get("weathercode", [])
				if not timeList:
					self.dayList = []
					return
				first_dt = _parse_datetime_compat(timeList[0])
				if first_dt is None:
					self.dayList = []
					return
				currday = first_dt.replace(hour=0, minute=0, second=0, microsecond=0)
				daycount = 0
				hourData = []
				for idx, isotime in enumerate(timeList):
					currtime = _parse_datetime_compat(isotime)
					if currtime is None:
						continue
					timeday = currtime.replace(hour=0, minute=0, second=0, microsecond=0)
					if timeday > currday and hourData:
						dayList.append(hourData)
						hourData = []
						currday = timeday
						daycount += 1
					timestr = currtime.strftime("%H:%M h")
					press = str(round(_list_get_compat(pressList, idx, 0))) + " mbar"
					tempunit = "°C" if config.plugins.OAWeatheriet5.tempUnit.value == "Celsius" else "°F"
					temp = str(round(_list_get_compat(tempList, idx, 0))) + " " + tempunit
					feels = str(round(_list_get_compat(feelsList, idx, 0))) + " " + tempunit
					humid = str(round(_list_get_compat(humidList, idx, 0))) + " %"
					precip = str(round(_list_get_compat(precipList, idx, 0))) + " %"
					windSpd = str(round(_list_get_compat(wSpeedList, idx, 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
					windDir = _(weatherhandler.WI.directionsign(round(round(_list_get_compat(wDirList, idx, 0)))))
					windGusts = str(round(_list_get_compat(wGustList, idx, 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
					uvIndex = str(round(_list_get_compat(uvList, idx, 0)))
					visibility = str(round(_list_get_compat(visList, idx, 0) / 1000)) + " km"
					shortDesc, longDesc = "", ""  # OMW does not support description texts at all
					sunrise_ref = _list_get_compat(sunriseList, daycount, "")
					sunset_ref = _list_get_compat(sunsetList, daycount, "")
					isNight = self.getIsNight(currtime, sunrise_ref, sunset_ref)
					yahoocode = self.nightSwitch(_get_yahoo_code_compat("OMW", _list_get_compat(wCodeList, idx, "NA")), isNight)  # e.g. '1' -> {'yahooCode': '34', 'meteoCode': 'B'}
					iconfile = join(iconpath, yahoocode + ".png")
					raw_data = [timestr, press, temp, feels, humid, precip, windSpd, windDir, windGusts, uvIndex, visibility, shortDesc, longDesc, iconpix_load]
					hourData.append([_safestr(x) for x in raw_data[:-1]] + [raw_data[-1]])
				if hourData:
					dayList.append(hourData)
			self.dayList = dayList

	def owmparser(self):
		iconpath = config.plugins.OAWeatheriet5.iconset.value
		iconpath = join(ICONSETROOT, iconpath) if iconpath else join(PLUGINPATH, "Icons")
		fulldata = weatherhandler.getFulldata()
		if fulldata:
			city = fulldata.get("city", {})
			sunriseTs, sunsetTs = city.get("sunrise", 0), city.get("sunset", 0)  # OM only supports sunrise/sunset of today
			sunrisestr = datetime.fromtimestamp(sunriseTs).isoformat() if sunriseTs else ""
			sunsetstr = datetime.fromtimestamp(sunsetTs).isoformat() if sunsetTs else ""
			self.sunList, self.moonList = [], []  # OMW does not support moonrise / moonset at all
			hourData = []
			tempunit = "°C" if config.plugins.OAWeatheriet5.tempUnit.value == "Celsius" else "°F"
			timeTs = fulldata.get("dt", 0)  # collect latest available data
			timestr = datetime.fromtimestamp(timeTs).strftime("%H:%M") if timeTs else ""
			main = fulldata.get("main", {})
			hourly = fulldata.get("list", [])
			press = str(round(main.get('pressure', 0))) + " mbar"
			temp = str(round(main.get('temp', 0))) + " " + tempunit
			feels = str(round(main.get('feels_like', 0))) + " " + tempunit
			humid = str(round(main.get('humidity', 0))) + " %"
			precip = str(round(hourly[0].get('pop', 0) * 100)) + " %" if hourly else self.na
			wind = fulldata.get('wind', {})
			windSpd = str(round(wind.get('speed', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
			windDir = _(weatherhandler.WI.directionsign(round(wind.get('deg', 0))))
			windGusts = str(round(hourly[0].get('wind', {}).get('gust', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s") if hourly else self.na
			uvIndex = ""  # OWM does not support UV-index at all
			visibility = str(round(fulldata.get('visibility', 0) / 1000)) + " km"
			weather = _first_dict_compat(fulldata.get("weather", []))
			shortDesc = weather.get("description", "")
			longDesc = ""  # OWM does not support long descriptions at all
			currtime = datetime.fromtimestamp(timeTs) if timeTs else None
			isNight = self.getIsNight(currtime, sunrisestr, sunsetstr)
			yahoocode = self.nightSwitch(_get_yahoo_code_compat("OWM", weather.get("id", "NA")), isNight)  # e.g. '801' -> {'yahooCode': '34', 'meteoCode': 'B'}
			iconfile = join(iconpath, yahoocode + ".png")
			iconpix_load = LoadPixmap(cached=True, path=iconfile) if iconfile and exists(iconfile) else self.pressPix
			hourData = []
			raw_data = [timestr, press, temp, feels, humid, precip, windSpd, windDir, windGusts, uvIndex, visibility, shortDesc, longDesc, iconpix_load]
			hourData.append([_safestr(x) for x in raw_data[:-1]] + [raw_data[-1]])
			dayList = []
			if hourly:
				first_dt = _parse_datetime_compat(hourly[0].get("dt_txt", "1900-01-01 00:00:00"))
				if first_dt is None:
					self.sunList = [(sunrisestr, sunsetstr)] if hourData else []
					self.dayList = [hourData] if hourData else []
					return
				currday = first_dt.replace(hour=0, minute=0, second=0, microsecond=0)
				for hour in hourly:  # collect data on future hours of current day
					isotime = hour.get("dt_txt", "1900-01-01 00:00:00")
					currtime = _parse_datetime_compat(isotime)
					if currtime is None:
						continue
					timeday = currtime.replace(hour=0, minute=0, second=0, microsecond=0)
					if timeday > currday and hourData:
						dayList.append(hourData)
						self.sunList.append((sunrisestr, sunsetstr))
						hourData = []
						currday = timeday
					main = hour.get("main", {})
					press = str(round(main.get('pressure', 0))) + " mbar"
					temp = str(round(main.get('temp', 0))) + " " + tempunit
					feels = str(round(main.get('feels_like', 0))) + " " + tempunit
					humid = str(round(main.get('humidity', 0))) + " %"
					precip = str(round(hour.get('pop', 0) * 100)) + " %"
					wind = hour.get("wind", {})
					windSpd = str(round(wind.get('speed', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
					windDir = _(weatherhandler.WI.directionsign(round(wind.get('deg', 0))))
					windGusts = str(round(wind.get('gust', 0))) + (" km/h" if config.plugins.OAWeatheriet5.windspeedMetricUnit.value == 'km/h' else " m/s")
					uvIndex = ""  # OWM does not support UV-index at all
					visibility = str(round(hour.get('visibility', 0) / 1000)) + " km"
					weather = _first_dict_compat(hour.get("weather", []))
					shortDesc = weather.get("description", "")
					longDesc = ""  # OWM does not support long descriptions at all
					timestr = currtime.strftime("%H:%M")
					isNight = self.getIsNight(currtime, sunrisestr, sunsetstr)
					yahoocode = self.nightSwitch(_get_yahoo_code_compat("OWM", weather.get("id", "NA")), isNight)
					iconfile = join(iconpath, yahoocode + ".png")
					raw_data = [timestr, press, temp, feels, humid, precip, windSpd, windDir, windGusts, uvIndex, visibility, shortDesc, longDesc, iconpix_load]
					hourData.append([_safestr(x) for x in raw_data[:-1]] + [raw_data[-1]])
				if hourData:
					dayList.append(hourData)
					self.sunList.append((sunrisestr, sunsetstr))
			elif hourData:
				dayList = [hourData]
				self.sunList.append((sunrisestr, sunsetstr))
			self.dayList = dayList

	def getIsNight(self, currtime, sunrisestr, sunsetstr):
		if sunrisestr and sunsetstr:
			sunrise = _parse_datetime_compat(sunrisestr)
			sunset = _parse_datetime_compat(sunsetstr)
			if sunrise is None or sunset is None or currtime is None:
				return False
			isNight = True if currtime < sunrise or currtime > sunset else False
		else:
			isNight = False
		return isNight

	def nightSwitch(self, iconcode, isNight):
		return self.YAHOOnightswitch.get(iconcode, iconcode) if config.plugins.OAWeatheriet5.nighticons.value and isNight else self.YAHOOdayswitch.get(iconcode, iconcode)

	def favoriteUp(self):
		if weatherhelper.favoriteList:
			self.currFavIdx = (self.currFavIdx - 1) % len(weatherhelper.favoriteList)
			self._updateLocationLabel(weatherhelper.favoriteList[self.currFavIdx])
			self["statustext"].text = _("Loading weather data...")
			callInThread(weatherhandler.reset, weatherhelper.favoriteList[self.currFavIdx], callback=self.parseData)

	def favoriteDown(self):
		if weatherhelper.favoriteList:
			self.currFavIdx = (self.currFavIdx + 1) % len(weatherhelper.favoriteList)
			self._updateLocationLabel(weatherhelper.favoriteList[self.currFavIdx])
			self["statustext"].text = _("Loading weather data...")
			callInThread(weatherhandler.reset, weatherhelper.favoriteList[self.currFavIdx], callback=self.parseData)

	# def favoriteChoice(self):
		# choiceList = [(item[0], item) for item in weatherhelper.favoriteList]
		# self.session.openWithCallback(self.returnFavoriteChoice, ChoiceBox, titlebartext=_("Select desired location"), title="", list=choiceList)

	# def returnFavoriteChoice(self, favorite):
		# if favorite is not None:
			# callInThread(weatherhandler.reset, favorite[1], callback=self.parseData)

	def favoriteChoice(self):
		choiceList = [(item[0], item) for item in weatherhelper.favoriteList]
		self.session.openWithCallback(
			self.returnFavoriteChoice,
			ChoiceBox,
			title=_("Select location"),
			list=choiceList
		)

	def returnFavoriteChoice(self, favorite):
		location = favorite[1] if isinstance(favorite, tuple) and len(favorite) > 1 else favorite
		weatherhelper.handleFavoriteSelection(favorite, self.parseData)
		if location in weatherhelper.favoriteList:
			self.currFavIdx = weatherhelper.favoriteList.index(location)
		self._updateLocationLabel(location)

	def prevEntry(self):
		self._setDetailListIndex(self._getDetailListIndex() - 1)

	def nextEntry(self):
		self._setDetailListIndex(self._getDetailListIndex() + 1)

	def pageDown(self):
		self._setDetailListIndex(self._getDetailListIndex() + self.detailPageSize)

	def pageUp(self):
		self._setDetailListIndex(self._getDetailListIndex() - self.detailPageSize)

	def prevDay(self):
		if not hasattr(self, 'dayList') or not self.dayList:
			self.session.open(
				MessageBox,
				_("Weather data unavailable"),
				MessageBox.TYPE_WARNING
			)
			return

		try:
			self.currdaydelta = (self.currdaydelta - 1) % len(self.dayList)
			self.currdatehour = datetime.today().replace(
				minute=0, second=0, microsecond=0
			) + timedelta(days=self.currdaydelta)
			self.updateDisplay()
		except Exception as e:
			logger.error("Weather day change error: %s" % _to_text_compat(e))
			self.session.open(
				MessageBox,
				_("Error changing day"),
				MessageBox.TYPE_ERROR
			)

	def nextDay(self):
		if not hasattr(self, 'dayList') or not self.dayList:
			self.session.open(
				MessageBox,
				_("Weather data unavailable"),
				MessageBox.TYPE_WARNING
			)
			return

		try:
			self.currdaydelta = (self.currdaydelta + 1) % len(self.dayList)
			self.currdatehour = datetime.today().replace(
				minute=0, second=0, microsecond=0
			) + timedelta(days=self.currdaydelta)
			self.updateDisplay()
		except Exception as e:
			logger.error("Weather day change error: %s" % _to_text_compat(e))
			self.session.open(
				MessageBox,
				_("Error changing day"),
				MessageBox.TYPE_ERROR
			)

	def updateDisplay(self):
		if self._closing:
			return
		if hasattr(self, 'dayList') and self.dayList:
			self.updateSkinList()
			self.updateMoonData()

	def config(self):
		self.old_weatherservice = config.plugins.OAWeatheriet5.weatherservice.value
		if self.detailFrameActive:
			self.detailFrame.hideFrame()
		self.session.openWithCallback(self.configFinished, WeatherSettingsViewNew)

	def configFinished(self, result=None):
		if self._closing:
			return
		self.detailLevels = config.plugins.OAWeatheriet5.detailLevel.choices
		self.detailLevelIdx = config.plugins.OAWeatheriet5.detailLevel.choices.index(
			config.plugins.OAWeatheriet5.detailLevel.value
		)
		if self.detailFrameActive:
			self.detailFrame.showFrame()
		if self.old_weatherservice != config.plugins.OAWeatheriet5.weatherservice.value:
			callInThread(weatherhandler.reset, callback=self.parseData)
		else:
			self.startRun()

	def exit(self):
		self._cleanupOnClose()
		self.close()


class OAWeatheriet5Favorites(Screen):
	def __init__(self, session):
		self.skin = weatherhelper.loadSkin("OAWeatheriet5Favorites")

		self["favoriteList"] = List(enableWrapAround=True)
		self["headline"] = StaticText(_("Manage Favorites"))
		self["key_red"] = StaticText(_("Delete"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText(_("Edit"))
		self["key_blue"] = StaticText(_("Add"))

		Screen.__init__(self, session)

		self.favoritefile = getattr(weatherhelper, "favoritefile", OAWEATHER_FAV)
		self._initFile()
		self.newFavList = weatherhelper.favoriteList[:]
		self.selected_index = None
		self.pending_changes = False

		self["actions"] = ActionMap(
			["OAWeatheriet5Favorites", "ColorActions", "OkCancelActions"],
			{
				"ok": self.onSelect,
				"cancel": self.onCancel,
				"red": self.onDelete,
				"green": self.onSave,
				"yellow": self.onEdit,
				"blue": self.startAddFavorite,
				"up": self.onUp,
				"down": self.onDown
			},
			-1
		)
		self.onShown.append(self.initScreen)

	def _initFile(self):
		"""Safely load a JSON file"""
		try:
			if not exists(self.favoritefile):
				with open(self.favoritefile, 'w') as f:
					json.dump([], f)
				chmod(self.favoritefile, 0o644)
				logger.info("File creato: " + str(self.favoritefile))
		except Exception as e:
			logger.error("File creation error: %s" % _to_text_compat(e))
			raise

	def initScreen(self):
		"""Initialize when screen becomes visible"""
		self._refreshList()
		self.checkCurrentLocation()

	def _refreshList(self):
		"""Update the list of favorites"""
		try:
			list_items = [
				(_to_gui_text_compat(fav[0]), _to_gui_text_compat("Lon: %.3f, Lat: %.3f" % (fav[1], fav[2])), idx)
				for idx, fav in enumerate(self.newFavList)
			]
			self["favoriteList"].setList(list_items)
		except Exception as e:
			logger.error("Update list error: %s" % _to_text_compat(e))
			self.showError(_("Error updating list"))

	def checkCurrentLocation(self):
		"""Highlight current location if present"""
		current = config.plugins.OAWeatheriet5.weatherlocation.value
		if current in self.newFavList:
			idx = self.newFavList.index(current)
			self["favoriteList"].setIndex(idx)

	def startAddFavorite(self):
		"""Start adding a new favorite location"""
		self.session.openWithCallback(
			self.cityNameEntered,
			VirtualKeyBoard,
			title=_("Enter city name (e.g. 'Rome, IT')"),
			text=""
		)

	def cityNameEntered(self, city_name):
		"""Handle the city name entered in VirtualKeyBoard"""
		if city_name:
			self._startCitySearch(city_name)

	def _startCitySearch(self, city_name):
		"""Start city search after name is entered"""
		if city_name and len(city_name) >= 3:
			weatherhelper.searchLocation(
				city_name,
				self._handleSearchResult,
				self.session
			)
		else:
			self._showMessage(_("Please enter at least 3 characters"), "warning")

	def _handleSearchResult(self, result):
		"""Handle search results in different formats"""
		if not result:
			logger.debug("Search cancelled by user")
			return

		try:
			logger.debug("Received search result: " + str(type(result)) + " - " + str(result))

			# CASE 1: Tuple with formatted string and separate data (MSN format)
			if (isinstance(result, tuple) and
					len(result) == 2 and
					isinstance(result[0], str) and
					'lon=' in result[0] and
					'lat=' in result[0] and
					isinstance(result[1], (tuple, list)) and
					len(result[1]) == 3):

				logger.debug("MSN format detected")
				formatted_str, data_tuple = result
				city_name = data_tuple[0]
				lon, lat = data_tuple[1], data_tuple[2]

			# CASE 2: String with coordinates in brackets
			elif isinstance(result, str) and '[' in result and ']' in result:
				logger.debug("String with coordinates detected")
				city_part, coords_part = result.split('[', 1)
				city_name = city_part.strip()
				coords = coords_part.replace(']', '').strip()

				if 'lon=' in coords and 'lat=' in coords:
					lon_str = coords.split('lon=')[1].split(',')[0].strip()
					lat_str = coords.split('lat=')[1].strip()
					lon = float(lon_str)
					lat = float(lat_str)
				else:
					raise ValueError("Invalid coordinate format")

			# CASE 3: Simple tuple (city, lon, lat)
			elif isinstance(result, (tuple, list)) and len(result) == 3:
				logger.debug("Simple tuple format detected")
				city_name, lon, lat = result[0], result[1], result[2]

			# CASE 4: City name only (fallback)
			elif isinstance(result, str):
				logger.debug("City name only received")
				city_name = result.strip()
				lon, lat = 0.0, 0.0
				self._showMessage(_("Coordinates not available for this location"), "warning")

			else:
				error_msg = "Unsupported result format: " + str(type(result))
				logger.error(error_msg)
				raise ValueError(error_msg)

			# Final validation
			if not city_name:
				error_msg = "Empty city name"
				logger.error(error_msg)
				raise ValueError(error_msg)

			logger.info("Adding new location: " + str(city_name) + " (" + str(lon) + ", " + str(lat) + ")")
			self._addToFavorites(city_name, lon, lat)

		except Exception as e:
			error_msg = "Error processing result: %s" % _to_text_compat(e) + " - Raw data: " + str(result)
			logger.error(error_msg)
			self._showMessage(_("Error processing location data"), "error")

	def _addToFavorites(self, city, lon, lat):
		"""Add validated location to favorites with simplified city name"""
		try:
			# Normalize city name: take only the part before first comma
			simple_city_name = city.split(',')[0].strip()

			new_fav = [
				simple_city_name,
				float(lon),
				float(lat)
			]

			# Check for duplicates
			for existing in self.newFavList:
				if existing[0].lower() == simple_city_name.lower():
					self._showMessage(_("Location already exists"), "info")
					return
				if abs(existing[1] - float(lon)) < 0.01 and abs(existing[2] - float(lat)) < 0.01:
					self._showMessage(_("Location with similar coordinates already exists"), "info")
					return

			self.newFavList.append(new_fav)
			self._refreshList()
			self.pending_changes = True
			logger.info("Added new favorite: " + str(new_fav))
			self._showMessage(_("Location added successfully"), "info")

		except ValueError as e:
			logger.error("Invalid location data: %s" % _to_text_compat(e))
			self._showMessage(_("Invalid location coordinates"), "error")
		except Exception as e:
			logger.error("Unexpected error: %s" % _to_text_compat(e))
			self._showMessage(_("Error adding location"), "error")

	def _showMessage(self, message, msg_type):
		"""Show messages to the user"""
		msg_map = {
			"info": MessageBox.TYPE_INFO,
			"warning": MessageBox.TYPE_WARNING,
			"error": MessageBox.TYPE_ERROR
		}

		if isinstance(msg_type, int):
			msgtype = msg_type
		else:
			msgtype = msg_map.get(msg_type.lower(), MessageBox.TYPE_INFO)

		self.session.open(
			MessageBox,
			message,
			msgtype,
			timeout=3
		)

	def onSelect(self):
		try:
			selected = self["favoriteList"].getCurrent()
			if not selected:
				return

			logger.debug("Selected item RAW: " + str(selected))

			# Get the original data from newFavList using the index
			if isinstance(selected, (tuple, list)) and len(selected) >= 3:
				location_data = self.newFavList[selected[2]]
			else:
				# Fallback if format is different
				location_data = selected

			logger.debug("Location data to save: " + str(location_data))

			# Update all relevant config values
			config.plugins.OAWeatheriet5.weathercity.value = location_data[0]
			config.plugins.OAWeatheriet5.owm_geocode.value = str(location_data[1]) + "," + str(location_data[2])
			config.plugins.OAWeatheriet5.weatherlocation.value = (location_data[0], location_data[1], location_data[2])

			# Save config immediately
			config.plugins.OAWeatheriet5.save()
			configfile.save()

			# Update weatherhelper favorites if needed
			if location_data not in weatherhelper.favoriteList:
				weatherhelper.addFavorite(location_data)

			logger.info("Config updated to: " + str(location_data[0]))

			# Reset weather data with new location
			callInThread(weatherhandler.reset, location_data)

			# Close and return selected location
			self.close(location_data)

		except Exception as e:
			logger.error("Selection failed: %s" % _to_text_compat(e))
			self._showMessage(_("Error selecting location"), MessageBox.TYPE_ERROR)

	def onCancel(self):
		if self.pending_changes:
			self.session.openWithCallback(
				self._handleExitConfirmation,
				MessageBox,
				_("You have unsaved changes. Save before exiting?"),
				MessageBox.TYPE_YESNO
			)
		else:
			self.close(None)

	def _handleExitConfirmation(self, result):
		if result is None:
			return
		elif result:
			self.onSave()
		else:
			self.close(None)

	def onDelete(self):
		"""Delete selected favorite"""
		current = self.getCurrentFavorite()
		if current:
			self.session.openWithCallback(
				lambda result: self.confirmDelete(current, result),
				MessageBox,
				_("Delete {}?").format(current[0]),
				MessageBox.TYPE_YESNO
			)

	def confirmDelete(self, favorite, confirmed):
		"""Delete location with full synchronization"""
		if confirmed:
			try:
				# 1. Remove from both lists
				if favorite in self.newFavList:
					self.newFavList.remove(favorite)
				if favorite in weatherhelper.favoriteList:
					weatherhelper.favoriteList.remove(favorite)

				# 2. Atomic save
				weatherhelper.saveFavorites()  # Uses helper's method

				# 3. Clear cache
				if exists(CACHEFILE):
					remove(CACHEFILE)

				# 4. Check if deleted was active location
				current_loc = config.plugins.OAWeatheriet5.weatherlocation.value
				if current_loc == favorite:
					config.plugins.OAWeatheriet5.weatherlocation.value = weatherhelper.locationDefault
					config.plugins.OAWeatheriet5.weathercity.value = weatherhelper.locationDefault[0]
					config.plugins.OAWeatheriet5.owm_geocode.value = str(weatherhelper.locationDefault[1]) + "," + str(weatherhelper.locationDefault[2])
					config.plugins.OAWeatheriet5.save()
					configfile.save()
					weatherhandler.reset(weatherhelper.locationDefault)

				# 5. Sync all configs
				weatherhelper.syncWithConfig()

				# 6. Update UI
				self._refreshList()
				self._showMessage(_("Location deleted"), MessageBox.TYPE_INFO)

			except Exception as e:
				logger.error("Delete error: %s" % _to_text_compat(e))
				self._showMessage(_("Delete failed"), MessageBox.TYPE_ERROR)

	def onSave(self):
		try:
			# Update both lists
			weatherhelper.favoriteList = self.newFavList[:]

			weatherhelper.saveFavorites()

			if exists(CACHEFILE):
				remove(CACHEFILE)

			self.pending_changes = False
			self._showMessage(_("Favorites saved successfully"), "info")

			weatherhelper.updateConfigChoices()

		except Exception as e:
			logger.error("Save error: %s" % _to_text_compat(e))
			self._showMessage(_("Error saving favorites"), "error")

	def onEdit(self):
		"""Edit selected item"""
		current = self.getCurrentFavorite()
		if current:
			self.selected_index = self["favoriteList"].getIndex()
			self.session.openWithCallback(
				self.handleEditResult,
				CustomVirtualKeyBoard,
				title=_("Edit city name"),
				text=_to_gui_text_compat(current[0])
			)

	def handleEditResult(self, new_name):
		"""Handle the result of editing a favorite's name"""
		if new_name:
			try:
				old = self.newFavList[self.selected_index]
				self.newFavList[self.selected_index] = (new_name, old[1], old[2])
				self.pending_changes = True
				self._refreshList()
			except IndexError:
				self.showError(_("Invalid selection"))

	def getCurrentFavorite(self):
		"""Return currently selected favorite"""
		idx = self["favoriteList"].getIndex()
		if 0 <= idx < len(self.newFavList):
			return self.newFavList[idx]
		return None

	def _getFavoriteIndex(self):
		try:
			return self["favoriteList"].getIndex()
		except Exception:
			return 0

	def _setFavoriteIndex(self, index):
		count = len(self.newFavList)
		if count > 0:
			self["favoriteList"].setIndex(index % count)

	def handleExitConfirmation(self, result, return_value):
		"""Handle exit decision"""
		if result is None:
			return
		elif result:
			self.onSave()
		else:
			self.close(return_value)

	def onUp(self):
		self._setFavoriteIndex(self._getFavoriteIndex() - 1)

	def onDown(self):
		self._setFavoriteIndex(self._getFavoriteIndex() + 1)


class TestScreen(Screen):
	"""Does not affect performance (used only in debug)"""
	skin = """
			<screen name="TestScreen"   position="center,center" size="1200,650" backgroundColor="#00000000"  transparent="0"  >
				<eLabel position="0,0" size="1200,650" backgroundColor="#00000000"    transparent="0" zPosition="0" />
				<ePixmap position="10,590" zPosition="3" size="240,50" pixmap=join(PLUGINPATH, "Images/")red.png" transparent="1" alphatest="blend" />
				<widget name="meinelist" position="100,20" size="1000,430" font="Regular;30" itemHeight="45"  backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="0" zPosition="3" scrollbarMode="showOnDemand" />
				<widget name="status" font="Regular; 25"  position="100,470" size="1000,40" foregroundColor ="#0000ff00" backgroundColor="#00000000" transparent="0"  zPosition="3" halign="center" valign="center" />
				<widget source="key_red" render="Label" position="10,570" zPosition="5" size="240,50" font="Regular;30" halign="center" valign="center" backgroundColor="#00313040" foregroundColor="#00ffffff" transparent="1" />
			</screen>
			"""

	def __init__(self, session, citylisttest, okCallback=None):
		self.session = session
		Screen.__init__(self, session)
		self.citylisttest = citylisttest
		self.okCallback = okCallback
		self['meinelist'] = MenuList(citylisttest)
		self.status = ""
		self["status"] = Label()
		self["actions"] = ActionMap(
			["OkCancelActions", "ColorActions"],
			{
				"ok": self.selectCity,
				"cancel": self.close,
				"red": self.close,
				"green": self.close,
				"yellow": self.close
			},
			-1
		)
		self['key_red'] = Label(_('exit'))
		self['status'].setText(_("Select the City and Press Ok"))

	def selectCity(self):
		selected_city_tuple = self['meinelist'].l.getCurrentSelection()
		if selected_city_tuple:
			selected_city = selected_city_tuple[0]
			self.selected_city = selected_city
			if self.okCallback is not None:
				self.okCallback(selected_city)
			self.close()
