# -*- coding: utf-8 -*-

from __future__ import absolute_import, print_function
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
import os
import sys


def _get_version():
	try:
		with open(os.path.join(os.path.dirname(__file__), 'version.txt'), 'r') as f:
			return f.read().strip()
	except Exception:
		return "4.1"

def _read_text_file(path, default=""):
	if not os.path.exists(path):
		return default
	try:
		with open(path, "r") as f:
			data = f.read()
	except Exception:
		return default

	try:
		if isinstance(data, bytes):
			return data.decode("utf-8", "ignore")
	except Exception:
		pass

	return data

def _collect_image_probe_text():
	parts = []
	for probe_path in (
		"/etc/image-version",
		"/etc/issue",
		"/etc/issue.net",
		"/etc/os-release",
		"/etc/opkg/all-feed.conf",
		"/etc/opkg/official-feed.conf",
		"/etc/opkg/custom-feed.conf",
		"/etc/hostname",
	):
		content = _read_text_file(probe_path, "").strip().lower()
		if content:
			parts.append(content)
	return "\n".join(parts)

def _detect_image_flags():
	"""
	Unified image detection used by the whole plugin.

	Goals:
	- Avoid duplicate/contradicting detection logic.
	- Avoid false Dreambox detection on OpenATV / VTI / OpenPLI images.
	- Keep the conditions explicit so other files can branch safely per image.
	"""
	probe_text = _collect_image_probe_text()

	is_vti = (
		os.path.exists("/etc/vti-version") or
		"vti" in probe_text
	)

	is_openatv = (
		os.path.exists("/etc/openatv-version") or
		"openatv" in probe_text
	)

	is_openpli = "openpli" in probe_text
	is_openbh = "openbh" in probe_text
	is_openvix = "openvix" in probe_text
	is_openspa = "openspa" in probe_text
	is_openvision = "openvision" in probe_text
	is_openeight = "openeight" in probe_text
	is_egami = "egami" in probe_text

	dream_markers = (
		"/etc/dpkg/origins/dreambox",
		"/etc/dreambox-image-version",
		"/etc/opkg/dreambox-feed.conf",
	)

	is_dreambox = any(os.path.exists(path) for path in dream_markers)

	if not is_dreambox:
		if any(marker in probe_text for marker in (
			"dreambox",
			"dreamos",
			"dream multimedia",
			"dream property"
		)):
			is_dreambox = True

	# Fallback only when image is not already recognized as OpenATV / VTI / OpenPLI
	if not is_dreambox and not is_openatv and not is_vti and not is_openpli:
		if (
			os.path.exists("/usr/bin/apt-get") and
			(os.path.exists("/etc/apt") or os.path.exists("/var/lib/dpkg/status"))
		):
			is_dreambox = True

	is_open_source_image = bool(
		not is_dreambox or
		is_openatv or
		is_vti or
		is_openpli or
		is_openbh or
		is_openvix or
		is_openspa or
		is_openvision or
		is_openeight or
		is_egami
	)

	return {
		"isDreambox": bool(is_dreambox),
		"isVTi": bool(is_vti),
		"isOpenATV": bool(is_openatv),
		"isOpenPLI": bool(is_openpli),
		"isOpenBH": bool(is_openbh),
		"isOpenViX": bool(is_openvix),
		"isOpenSpa": bool(is_openspa),
		"isOpenVision": bool(is_openvision),
		"isOpenEight": bool(is_openeight),
		"isEgami": bool(is_egami),
		"isOpenSourceImage": is_open_source_image,
	}


def _collect_box_probe_text():
	parts = []
	for probe_path in (
		"/proc/stb/info/model",
		"/proc/stb/info/boxtype",
		"/proc/stb/info/vumodel",
		"/etc/model",
		"/etc/hostname",
	):
		content = _read_text_file(probe_path, "").strip().lower()
		if content:
			parts.append(content)
	return "\n".join(parts)


def _detect_box_flags():
	box_text = _collect_box_probe_text()
	is_dm920 = "dm920" in box_text
	is_vuplus = any(marker in box_text for marker in (
		"vu",
		"vuplus",
		"vusolo",
		"vuduo",
		"vuultimo",
		"vuzero"
	))
	return {
		"boxModel": box_text.splitlines()[0] if box_text else "",
		"isDM920": bool(is_dm920),
		"isVuPlus": bool(is_vuplus),
	}


def _append_package_path(package_name, package_path):
	if not package_path or not os.path.isdir(package_path):
		return False

	try:
		package_module = __import__(package_name, fromlist=["*"])
	except Exception:
		package_module = None

	normalized_target = os.path.normcase(os.path.abspath(package_path))

	if package_module is not None:
		package_paths = getattr(package_module, "__path__", None)
		if package_paths is not None:
			try:
				existing_paths = [os.path.normcase(os.path.abspath(item)) for item in list(package_paths)]
			except Exception:
				existing_paths = []

			if normalized_target not in existing_paths:
				try:
					package_paths.append(package_path)
					return True
				except Exception:
					try:
						package_module.__path__ = list(package_paths) + [package_path]
						return True
					except Exception:
						pass

	try:
		sys_paths = [os.path.normcase(os.path.abspath(item)) for item in sys.path]
	except Exception:
		sys_paths = []

	if normalized_target not in sys_paths:
		try:
			sys.path.insert(0, package_path)
		except Exception:
			return False

	return True


def _register_plugin_python_paths():
	plugin_root = os.path.dirname(__file__)
	component_root = os.path.join(plugin_root, "Components")
	path_map = {
		"Components.Converter": os.path.join(component_root, "Converter"),
		"Components.Renderer": os.path.join(component_root, "Renderer"),
		"Components.Sources": os.path.join(component_root, "Sources"),
		"Tools": os.path.join(plugin_root, "Tools"),
	}

	for package_name, package_path in path_map.items():
		try:
			_append_package_path(package_name, package_path)
		except Exception:
			pass

__version__ = _get_version()

PluginLanguageDomain = 'OAWeatheriet5'
PluginLanguagePath = 'Extensions/OAWeatheriet5/locale'
PluginLanguageFallbackPath = os.path.join(os.path.dirname(__file__), 'locale')

IMAGE_INFO = _detect_image_flags()
BOX_INFO = _detect_box_flags()
IMAGE_INFO.update(BOX_INFO)
isDreambox = IMAGE_INFO["isDreambox"]
isVTi = IMAGE_INFO["isVTi"]
isOpenATV = IMAGE_INFO["isOpenATV"]
isOpenPLI = IMAGE_INFO["isOpenPLI"]
isOpenBH = IMAGE_INFO["isOpenBH"]
isOpenViX = IMAGE_INFO["isOpenViX"]
isOpenSpa = IMAGE_INFO["isOpenSpa"]
isOpenVision = IMAGE_INFO["isOpenVision"]
isOpenEight = IMAGE_INFO["isOpenEight"]
isEgami = IMAGE_INFO["isEgami"]
isOpenSourceImage = IMAGE_INFO["isOpenSourceImage"]
isDM920 = IMAGE_INFO["isDM920"]
isVuPlus = IMAGE_INFO["isVuPlus"]
boxModel = IMAGE_INFO["boxModel"]

_register_plugin_python_paths()

def _get_locale_path():
	try:
		resolved = resolveFilename(SCOPE_PLUGINS, PluginLanguagePath)
	except Exception:
		resolved = ""

	if resolved and os.path.exists(resolved):
		return resolved

	return PluginLanguageFallbackPath


def localeInit():
	try:
		lang = language.getLanguage() or ""
	except Exception:
		lang = ""

	if lang:
		lang_short = lang[:2]
		try:
			if lang_short and lang_short != lang:
				os.environ["LANGUAGE"] = "%s:%s" % (lang, lang_short)
			else:
				os.environ["LANGUAGE"] = lang
		except Exception:
			pass

	try:
		gettext.bindtextdomain(PluginLanguageDomain, _get_locale_path())
	except Exception:
		pass

if isDreambox:
	def _(txt):
		return gettext.dgettext(PluginLanguageDomain, txt) if txt else ""
else:
	def _(txt):
		if not txt:
			return ""
		try:
			translated = gettext.dgettext(PluginLanguageDomain, txt)
			if translated and translated != txt:
				return translated
		except Exception:
			pass
		try:
			return gettext.gettext(txt)
		except Exception:
			return txt

localeInit()

try:
	language.addCallback(localeInit)
except Exception:
	pass
